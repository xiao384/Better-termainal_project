# ============================================================
# ui.py — 图形界面模块
#   - sign_in() : 登录验证
#   - main()    : 终端主窗口（主题跟随系统）
#   - launch()  : 创建登录窗口并启动主循环
#   - reboot()  : 重启终端（重新登录）
# ============================================================
import json
import os
import platform
import subprocess
import sys
import tkinter as tk
from tkinter import messagebox

import config
import theme
from commands import run_cmd_text
from system_os import SYSTEM_OS


def sign_in():
    # 账户与密码读取
    with open(os.path.join(config.__run_path__, 'users_data.json'), 'r', encoding='utf-8') as f:
        list_data = json.load(f)
        list_name = list_data['users_name']
        list_password = list_data['users_password']
        list_root = list_data['users_root']
    input_name = config.tk_input_name.get()
    input_password = config.tk_input_key.get()

    # 逐用户匹配用户名与密码，避免认证绕过
    config.users_permission = False
    users_permission_detailed = ''
    for i in range(len(list_name)):
        if list_name[i] == input_name and list_password[i] == input_password:
            config.users_permission = True
            users_permission_detailed = list_root[i]
            if list_root[i] == 'root':
                config.root_permission = True
            break

    if config.users_permission:
        config.root = SYSTEM_OS(config.__system_name__, input_name, users_permission_detailed)
    else:
        messagebox.showerror('错误', '用户名或密码错误')
    main()


def main():
    print(config.users_permission, config.root_permission)
    if config.users_permission:
        C = theme.get_theme()
        config.sign_tk.destroy()
        config.main_tk = tk.Tk()
        config.main_tk.title(f'bash-{platform.system()}{platform.release()}--{config.root.users_name}--{config.root.users_permission_detailed}')
        config.main_tk.geometry('700x600')
        config.main_tk.configure(bg=C['bg'])
        return_text_tk = theme.text(config.main_tk, C, wrap='word', font=('Consolas', 10))
        return_text_tk.pack(fill='both', expand=True, padx=5, pady=5)
        return_text_tk.config(state='disabled')  # 禁止用户直接编辑
        # 文本着色标签：提示符 / 错误
        return_text_tk.tag_configure('prompt', foreground=C['prompt'])
        return_text_tk.tag_configure('error', foreground=C['error'])
        Entry_cmd = theme.entry(config.main_tk, C, font=('Consolas', 10))
        Entry_cmd.pack(side='left', fill='x', expand=True)

        def return_set_cmd():
            text_input = Entry_cmd.get()
            return_text = run_cmd_text(text_input)
            # 临时启用以写入输出
            return_text_tk.config(state='normal')
            return_text_tk.insert('end', f">>> {text_input}\n", 'prompt')
            return_text_tk.insert('end', return_text + '\n')
            return_text_tk.see('end')
            return_text_tk.config(state='disabled')
            Entry_cmd.delete(0, 'end')

        Entry_cmd.bind('<Return>', lambda e: return_set_cmd())
        config.main_tk.mainloop()


def launch():
    """创建登录窗口并启动主循环"""
    C = theme.get_theme()
    config.sign_tk = tk.Tk()
    config.sign_tk.title('shell_open')
    config.sign_tk.geometry('300x200')
    config.sign_tk.configure(bg=C['bg'])
    first_label = theme.label(config.sign_tk, "输入用户名和密码登录：", C)
    first_label.pack()
    config.tk_input_name = theme.entry(config.sign_tk, C)
    config.tk_input_name.pack(pady=10)
    config.tk_input_key = theme.entry(config.sign_tk, C, show='*')
    config.tk_input_key.pack(pady=10)
    first_button = theme.button(config.sign_tk, 'submit', sign_in, C)
    first_button.pack(pady=10)
    config.sign_tk.mainloop()


def reboot():
    """重启终端：销毁当前窗口，重新启动进程（需重新登录）"""
    for win in (config.main_tk, config.sign_tk):
        if win is not None:
            try:
                win.destroy()
            except Exception:
                pass
    # 以新进程重新启动主程序，避免 mainloop 嵌套
    subprocess.Popen([sys.executable, os.path.abspath(sys.argv[0])])
    sys.exit(0)
