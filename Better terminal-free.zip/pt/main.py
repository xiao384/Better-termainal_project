# ============================================================
# main.py — 程序入口模块
# 说明: Better terminal_project.py 文件名含空格，无法被 import，
#       因此把入口逻辑放在本模块，由主程序文件调用 run_main()。
#   - run_main() : 启动终端（登录窗口）
# ============================================================
from ui import launch


def run_main():
    """启动终端（登录窗口）"""
    launch()


if __name__ == '__main__':
    run_main()