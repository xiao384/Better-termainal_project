# ============================================================
# commands.py — 命令解析与分发模块
# 将终端输入的命令字符串解析并分发给 SYSTEM_OS 对应方法
# ============================================================
import config


def run_cmd_text(text_input):
    # 分割命令和参数（如 "open_file test.txt" → cmd="open_file", args="test.txt"）
    parts = text_input.split(maxsplit=1)
    cmd = parts[0]
    args = parts[1] if len(parts) > 1 else ''
    agree_run = ['turn_off_system', 'message', 'help', 'open', 'users', 'sudo', 'Auto-output','reboot bash']
    if cmd in agree_run:
        if cmd == 'help':
            return config.root.help
        elif cmd == 'turn_off_system':
            return config.root.turn_off_system
        elif cmd == 'message':
            return config.root.message
        elif cmd == 'open':
            if not args:
                return '用法: open <文件路径>'
            return config.root.open_file(args)
        elif cmd == 'users':
            return config.root.users(args)
        elif cmd == 'sudo':
            return config.root.sudo_permission(args)
        elif cmd == 'Auto-output':
            return config.root.auto_output(args)
        elif cmd == 'reboot bash':
            return config.root.reboot_bash
        return f'命令 "{cmd}" 暂未实现'

    else:
        return ('错误，未存在命令\n'
                '你可以输入help来查询可用命令')
