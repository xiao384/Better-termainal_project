# ============================================================
# system_os.py — 系统操作模块（哈希版）
# 包含: SYSTEM_OS 类
#   - message / help       : 系统信息与帮助
#   - turn_off_system      : 关机(root)
#   - open_file            : 打开并编辑文件
#   - users 系列           : 用户管理（SHA-256 哈希密码）
#   - sudo_permission      : sudo 提权（哈希验证）
#   - auto_output          : 自动输出
# ============================================================
import json
import os
import platform
import subprocess
import time
import random
import tkinter as tk
from tkinter import messagebox

import pyautogui
import pyperclip

import config
import theme
from auth import hash_password, verify_password

class SYSTEM_OS:
    def __init__(self, __system_name__, users_name, users_permission_detailed):
        self.system_name = __system_name__
        self.users_name = users_name
        self.users_permission_detailed = users_permission_detailed

    @property
    def message(self):
        cpu_info = platform.processor() or platform.machine()
        result_message = (f'系统:{platform.platform()}\nCPU:{platform.machine()}--{cpu_info}\n'
                          f'用户:{self.users_name}\n权限:{self.users_permission_detailed}')
        return result_message

    @property
    def help(self):
        cmd_list = [
            'help: 帮助界面',
            'message: 系统信息',
            'turn_off_system: 关机(root)',
            'open <路径>: 打开并编辑文件',
            'users: 查看当前用户信息',
            'users list: 列出所有用户',
            'users modify <用户名>: 修改用户密码/权限 (root)',
            'users add: 添加新用户 (root)',
            'users delete <用户名>: 删除用户 (root)',
            'sudo root: 获得root权限',
            'Auto-output <选择1,文件内容;2,输入内容>: 自动输出内容',
            'reboot bash:重启终端(需重新登录)',
        ]
        return '\n'.join(cmd_list)

    # 重启终端
    @property
    def reboot_bash(self):
        # 延迟导入 ui，避免与 ui.py 产生循环依赖
        from ui import reboot
        return reboot()

    # 关机功能
    @property
    def turn_off_system(self):
        # 根据操作系统选择关机命令
        system = platform.system()
        if self.users_permission_detailed == 'root':
            if system == "Windows":
                shutdown_cmd = ["shutdown", "/s", "/t", "1"]
            elif system == "Linux":
                shutdown_cmd = ["shutdown", "now"]
            elif system == "Darwin":  # macOS
                shutdown_cmd = ["osascript", "-e",
                                'tell app "System Events" to shut down']
            else:
                return f"当前系统 ({system}) 暂不支持关机命令"
        else:
            return "权限不足：关机操作需要 root 权限"
        # 使用列表在闭包中传递用户确认结果
        confirmed = [False]
        def finally_turn_off():
            confirmed[0] = True
            turn_off_confirm.destroy()
            try:
                subprocess.run(shutdown_cmd, check=True)
            except subprocess.CalledProcessError as e:
                messagebox.showerror("关机失败",
                    f"命令执行失败: {e}\n请检查是否有足够权限。")
        def cancel_turn_off():
            turn_off_confirm.destroy()
        C = theme.get_theme()
        turn_off_confirm = tk.Toplevel(config.main_tk)
        turn_off_confirm.title('确认关机')
        turn_off_confirm.geometry('250x120')
        turn_off_confirm.resizable(False, False)
        turn_off_confirm.configure(bg=C['bg'])
        theme.label(turn_off_confirm, f'确认要关机吗？\n({system})', C,
                    font=('', 10)).pack(pady=10)
        btn_frame = tk.Frame(turn_off_confirm, bg=C['bg'])
        btn_frame.pack(pady=10)
        theme.button(btn_frame, '确认关机', finally_turn_off, C,
                     bg='#c42b1c', width=8).pack(side='left', padx=10)
        theme.button(btn_frame, '取消', cancel_turn_off, C,
                     width=8).pack(side='left', padx=10)
        # 阻塞等待用户确认
        turn_off_confirm.grab_set()
        config.main_tk.wait_window(turn_off_confirm)
        if confirmed[0]:
            return '系统正在关机...'
        else:
            return '已取消关机'

    # 文件打开功能
    def open_file(self, file_path):
        if not os.path.exists(file_path):
            return f'文件不存在: {file_path}'
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            return f'读取文件失败: {e}'
        # 创建文件编辑窗口
        C = theme.get_theme()
        open_file_tk = tk.Toplevel(config.main_tk)
        open_file_tk.title(file_path)
        open_file_tk.geometry('500x400')
        open_file_tk.configure(bg=C['bg'])
        # 菜单栏
        menubar = tk.Menu(open_file_tk, bg=C['bg'], fg=C['fg'],
                          activebackground=C['button_active'], activeforeground=C['fg'])
        file_menu = tk.Menu(menubar, tearoff=0,
                            bg=C['bg'], fg=C['fg'],
                            activebackground=C['button_active'], activeforeground=C['fg'])
        def save_file():
            try:
                new_content = text_widget.get("1.0", "end-1c")
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(new_content)
                messagebox.showinfo('提示', f'文件已保存: {file_path}')
            except Exception as e:
                messagebox.showerror('保存失败', str(e))
        def close_window():
            open_file_tk.destroy()
        file_menu.add_command(label='保存 (Ctrl+S)', command=save_file)
        file_menu.add_separator()
        file_menu.add_command(label='关闭', command=close_window)
        menubar.add_cascade(label='文件', menu=file_menu)
        open_file_tk.config(menu=menubar)
        # 文本编辑区
        text_widget = theme.text(open_file_tk, C, wrap='word', font=('Consolas', 10))
        text_widget.insert('1.0', content)
        text_widget.pack(fill='both', expand=True, padx=5, pady=5)
        # Ctrl+S 快捷键
        open_file_tk.bind('<Control-s>', lambda e: save_file())
        return f'已打开文件: {file_path}'

    # ==================== 用户管理（哈希密码） ====================
    def _load_users_data(self):
        """加载 users_data.json 数据"""
        with open(os.path.join(config.__run_path__, 'users_data.json'), 'r', encoding='utf-8') as f:
            return json.load(f)

    def _save_users_data(self, data):
        """保存数据到 users_data.json"""
        with open(os.path.join(config.__run_path__, 'users_data.json'), 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=4)

    def users(self, args_str):
        """用户管理入口
        用法:
          users                 → 查看当前用户信息
          users list            → 列出所有用户
          users modify <用户名>  → 修改用户密码/权限 (需 root)
          users add             → 添加新用户 (需 root)
          users delete <用户名>  → 删除用户 (需 root)
        """
        args = args_str.split() if args_str.strip() else []

        # ---- 无参数: 当前用户信息 ----
        if not args:
            return (f'当前用户: {self.users_name}\n'
                    f'权限: {self.users_permission_detailed}\n'
                    f'密码存储: SHA-256 哈希加密')

        sub_cmd = args[0]

        # ---- list: 列出所有用户 ----
        if sub_cmd == 'list':
            try:
                data = self._load_users_data()
            except Exception as e:
                return f'读取用户数据失败: {e}'
            lines = ['=== 用户列表 ===']
            for i in range(len(data['users_name'])):
                marker = ' ← 当前' if data['users_name'][i] == self.users_name else ''
                lines.append(f"  {data['users_name'][i]:12s}  权限: {data['users_root'][i]}{marker}")
            return '\n'.join(lines)

        # ---- 需要 root 的操作 ----
        if not config.root_permission:
            return '权限不足：修改用户信息需要 root 权限'

        if sub_cmd == 'modify':
            target = args[1] if len(args) > 1 else ''
            if not target:
                return '用法: users modify <用户名>'
            return self._modify_user_gui(target)

        elif sub_cmd == 'add':
            return self._add_user_gui()

        elif sub_cmd == 'delete':
            target = args[1] if len(args) > 1 else ''
            if not target:
                return '用法: users delete <用户名>'
            return self._delete_user(target)

        return (f'未知子命令: {sub_cmd}\n'
                f'可用: list | modify <用户名> | add | delete <用户名>')

    def _modify_user_gui(self, target):
        """GUI: 修改用户密码(哈希)和权限"""
        try:
            data = self._load_users_data()
        except Exception as e:
            return f'读取用户数据失败: {e}'

        if target not in data['users_name']:
            return f'用户 "{target}" 不存在'

        idx = data['users_name'].index(target)

        # ---- 创建修改窗口 ----
        C = theme.get_theme()
        win = tk.Toplevel(config.main_tk)
        win.title(f'修改用户: {target}')
        win.geometry('340x280')
        win.resizable(False, False)
        win.configure(bg=C['bg'])

        # 标题
        title_frame = tk.Frame(win, bg=C['bg'])
        title_frame.pack(fill='x', pady=10)
        theme.label(title_frame, '正在修改用户: ', C,
                    font=('', 10)).pack(side='left')
        theme.label(title_frame, target, C,
                    font=('', 10, 'bold'), fg='#2196F3').pack(side='left')

        # 新密码
        theme.label(win, '新密码 (留空则不修改):', C).pack(anchor='w', padx=20)
        pwd_entry = theme.entry(win, C, show='*', width=35)
        pwd_entry.pack(pady=5)

        # 确认密码
        theme.label(win, '确认新密码:', C).pack(anchor='w', padx=20)
        pwd_confirm_entry = theme.entry(win, C, show='*', width=35)
        pwd_confirm_entry.pack(pady=5)

        # 权限选择
        theme.label(win, '用户权限:', C).pack(anchor='w', padx=20, pady=(10, 0))
        perm_var = tk.StringVar(value=data['users_root'][idx])
        perm_frame = tk.Frame(win, bg=C['bg'])
        perm_frame.pack(pady=5)
        theme.radiobutton(perm_frame, 'root  (管理员)', perm_var, 'root', C,
                          font=('', 9)).pack(side='left', padx=15)
        theme.radiobutton(perm_frame, 'users (普通用户)', perm_var, 'users', C,
                          font=('', 9)).pack(side='left', padx=15)

        # 提示当前哈希
        theme.label(win, f'当前哈希: {data["users_password_hash"][idx][:16]}...', C,
                    fg='#888', font=('', 8)).pack(pady=(5, 0))

        def do_save():
            new_pwd = pwd_entry.get()
            pwd_confirm = pwd_confirm_entry.get()

            # 密码校验
            if new_pwd:
                if new_pwd != pwd_confirm:
                    messagebox.showerror('错误', '两次输入的密码不一致')
                    return
                # 生成新的哈希和盐值
                h, s = hash_password(new_pwd)
                data['users_password_hash'][idx] = h
                data['users_password_salt'][idx] = s

            data['users_root'][idx] = perm_var.get()

            try:
                self._save_users_data(data)
            except Exception as e:
                messagebox.showerror('保存失败', str(e))
                return

            # 如果修改了当前登录用户, 同步更新运行时状态
            if target == self.users_name:
                self.users_permission_detailed = perm_var.get()
                config.root_permission = (perm_var.get() == 'root')

            messagebox.showinfo('成功', f'用户 "{target}" 已更新')
            win.destroy()

        btn_frame = tk.Frame(win, bg=C['bg'])
        btn_frame.pack(pady=15)
        theme.button(btn_frame, '保存修改', do_save, C, width=12,
                     bg='#4CAF50').pack(side='left', padx=10)
        theme.button(btn_frame, '取消', win.destroy, C, width=12).pack(side='left', padx=10)

        win.grab_set()
        config.main_tk.wait_window(win)
        return f'用户 "{target}" 修改完成'

    def _add_user_gui(self):
        """GUI: 添加新用户（哈希密码）"""
        C = theme.get_theme()
        win = tk.Toplevel(config.main_tk)
        win.title('添加新用户')
        win.geometry('340x400')
        win.resizable(False, False)
        win.configure(bg=C['bg'])

        theme.label(win, '创建新用户 (SHA-256 哈希加密)', C,
                    font=('', 11, 'bold')).pack(pady=10)

        # 用户名
        theme.label(win, '用户名:', C).pack(anchor='w', padx=20)
        name_entry = theme.entry(win, C, width=35)
        name_entry.pack(pady=5)

        # 密码
        theme.label(win, '密码:', C).pack(anchor='w', padx=20)
        pwd_entry = theme.entry(win, C, show='*', width=35)
        pwd_entry.pack(pady=5)

        # 确认密码
        theme.label(win, '确认密码:', C).pack(anchor='w', padx=20)
        pwd_confirm_entry = theme.entry(win, C, show='*', width=35)
        pwd_confirm_entry.pack(pady=5)

        # 权限
        theme.label(win, '用户权限:', C).pack(anchor='w', padx=20, pady=(10, 0))
        perm_var = tk.StringVar(value='users')
        perm_frame = tk.Frame(win, bg=C['bg'])
        perm_frame.pack(pady=5)
        theme.radiobutton(perm_frame, 'root  (管理员)', perm_var, 'root', C,
                          font=('', 9)).pack(side='left', padx=15)
        theme.radiobutton(perm_frame, 'users (普通用户)', perm_var, 'users', C,
                          font=('', 9)).pack(side='left', padx=15)

        def do_add():
            new_name = name_entry.get().strip()
            new_pwd = pwd_entry.get()
            pwd_confirm = pwd_confirm_entry.get()

            if not new_name:
                messagebox.showerror('错误', '用户名不能为空')
                return
            if not new_pwd:
                messagebox.showerror('错误', '密码不能为空')
                return
            if new_pwd != pwd_confirm:
                messagebox.showerror('错误', '两次输入的密码不一致')
                return
            try:
                data = self._load_users_data()
            except Exception as e:
                messagebox.showerror('错误', f'读取用户数据失败: {e}')
                return

            if new_name in data['users_name']:
                messagebox.showerror('错误', f'用户 "{new_name}" 已存在')
                return

            # 生成哈希密码
            h, s = hash_password(new_pwd)

            data['users_name'].append(new_name)
            data['users_password_hash'].append(h)
            data['users_password_salt'].append(s)
            data['users_root'].append(perm_var.get())

            try:
                self._save_users_data(data)
            except Exception as e:
                messagebox.showerror('保存失败', str(e))
                return

            messagebox.showinfo('成功', f'用户 "{new_name}" 已创建\n密码已 SHA-256 哈希加密存储')
            win.destroy()

        btn_frame = tk.Frame(win, bg=C['bg'])
        btn_frame.pack(pady=15)
        theme.button(btn_frame, '添加用户', do_add, C, width=12,
                     bg='#4CAF50').pack(side='left', padx=10)
        theme.button(btn_frame, '取消', win.destroy, C, width=12).pack(side='left', padx=10)

        win.grab_set()
        config.main_tk.wait_window(win)
        return '用户添加操作已完成'

    def _delete_user(self, target):
        """删除用户"""
        try:
            data = self._load_users_data()
        except Exception as e:
            return f'读取用户数据失败: {e}'

        if target not in data['users_name']:
            return f'用户 "{target}" 不存在'

        if target == self.users_name:
            return '不能删除当前登录的用户'

        idx = data['users_name'].index(target)

        # 确认对话框
        confirmed = [False]
        C = theme.get_theme()
        win = tk.Toplevel(config.main_tk)
        win.title('确认删除')
        win.geometry('300x130')
        win.resizable(False, False)
        win.configure(bg=C['bg'])
        theme.label(win, f'确认要删除用户 "{target}" 吗？', C,
                    font=('', 10)).pack(pady=15)
        theme.label(win, '此操作不可撤销！', C, fg=C['error']).pack()

        def do_delete():
            confirmed[0] = True
            win.destroy()

        btn_frame = tk.Frame(win, bg=C['bg'])
        btn_frame.pack(pady=15)
        theme.button(btn_frame, '确认删除', do_delete, C, width=12,
                     bg='#f44336').pack(side='left', padx=10)
        theme.button(btn_frame, '取消', win.destroy, C, width=12).pack(side='left', padx=10)

        win.grab_set()
        config.main_tk.wait_window(win)

        if not confirmed[0]:
            return '已取消删除'

        del data['users_name'][idx]
        del data['users_password_hash'][idx]
        del data['users_password_salt'][idx]
        del data['users_root'][idx]

        try:
            self._save_users_data(data)
        except Exception as e:
            return f'保存失败: {e}'

        return f'用户 "{target}" 已删除'

    # sudo 功能
    def sudo_permission(self, account):
        """sudo 提权 — 输入 root 密码获得管理员权限 (哈希验证)"""
        if account != 'root':
            return '用法: sudo root'

        result = [None]  # 用列表在闭包中传递结果

        def sign_in_sudo():
            password_input = sudo_permission_tk_Entry.get()
            if not password_input:
                messagebox.showerror('错误', '请输入密码')
                return

            # 读取用户数据（哈希版）
            with open(os.path.join(config.__run_path__, 'users_data.json'),
                      'r', encoding='utf-8') as f:
                list_data = json.load(f)
            list_name = list_data['users_name']
            list_hash = list_data['users_password_hash']
            list_salt = list_data['users_password_salt']

            # 查找 root 用户
            root_idx = None
            for i in range(len(list_name)):
                if list_name[i] == 'root':
                    root_idx = i
                    break

            if root_idx is None:
                messagebox.showerror('错误', '系统中不存在 root 用户')
                return

            if verify_password(password_input, list_salt[root_idx],
                               list_hash[root_idx]):
                config.root_permission = True
                self.users_permission_detailed = 'root'
                result[0] = '成功获得 root 权限'
                # 同步更新窗口标题
                config.main_tk.title(f'bash-{config.__system_name__}--{self.users_name}--root')
                sudo_permission_tk.destroy()
            else:
                messagebox.showerror('错误', 'root 密码错误')

        def cancel_sudo():
            sudo_permission_tk.destroy()

        C = theme.get_theme()
        sudo_permission_tk = tk.Toplevel(config.main_tk)
        sudo_permission_tk.geometry('260x160')
        sudo_permission_tk.resizable(False, False)
        sudo_permission_tk.title('sudo 提权')
        sudo_permission_tk.configure(bg=C['bg'])
        theme.label(sudo_permission_tk, '请输入 root 密码:', C).pack(pady=15)
        sudo_permission_tk_Entry = theme.entry(sudo_permission_tk, C, show='*')
        sudo_permission_tk_Entry.pack(pady=5)
        sudo_permission_tk_Entry.bind('<Return>', lambda e: sign_in_sudo())
        btn_frame = tk.Frame(sudo_permission_tk, bg=C['bg'])
        btn_frame.pack(pady=10)
        theme.button(btn_frame, '确认', sign_in_sudo, C,
                     width=10, bg="#4CAF50").pack(side='left', padx=10)
        theme.button(btn_frame, '取消', cancel_sudo, C,
                     width=10).pack(side='left', padx=10)
        sudo_permission_tk.grab_set()
        config.main_tk.wait_window(sudo_permission_tk)
        return result[0] if result[0] else '已取消'

    # Auto-output 功能
    def auto_output(self, choose):
        """自动输出 — 模拟键盘在终端中粘贴文本
        用法: Auto-output 1  (从文件读取)
              Auto-output 2  (手动输入内容)
        """
        if choose not in ('1', '2'):
            return '用法: Auto-output <1(文件内容) 或 2(手动输入)>'

        result = [None]  # 存储 (text, count, delay)

        def start_auto_output():
            # 1. 读取次数和倒计时
            try:
                count = int(auto_output_tk_Entry2.get())
                delay = int(auto_output_tk_Entry3.get())
            except ValueError:
                messagebox.showerror('错误', '次数和倒计时必须为整数')
                return
            if count <= 0 or delay < 0:
                messagebox.showerror('错误', '次数必须 > 0，倒计时必须 >= 0')
                return

            # 2. 读取文本内容
            if choose == '1':
                file_path = auto_output_tk_Entry.get().strip()
                if not file_path:
                    messagebox.showerror('错误', '请输入文件路径')
                    return
                if not os.path.exists(file_path):
                    messagebox.showerror('错误', f'文件不存在: {file_path}')
                    return
                try:
                    with open(file_path, 'r', encoding='utf-8') as f:
                        text = f.read()
                except Exception as e:
                    messagebox.showerror('错误', f'读取文件失败: {e}')
                    return
            else:  # choose == '2'
                text = auto_output_tk_Entry.get()
                if not text.strip():
                    messagebox.showerror('错误', '请输入要输出的内容')
                    return

            # 3. 关闭窗口，传递结果
            auto_output_tk.destroy()
            result[0] = (text, count, delay)

        # ---- 创建配置窗口 ----
        C = theme.get_theme()
        auto_output_tk = tk.Toplevel(config.main_tk)
        auto_output_tk.title('Auto-output')
        auto_output_tk.geometry('450x350')
        auto_output_tk.resizable(False, False)
        auto_output_tk.configure(bg=C['bg'])

        if choose == '1':
            theme.label(auto_output_tk, '请输入要自动输出的文件路径:', C).pack(pady=(15, 5))
            auto_output_tk_Entry = theme.entry(auto_output_tk, C, width=50)
            auto_output_tk_Entry.pack(pady=5)
        else:
            theme.label(auto_output_tk, '请输入要自动输出的内容:', C).pack(pady=(15, 5))
            auto_output_tk_Entry = theme.entry(auto_output_tk, C, width=50)
            auto_output_tk_Entry.pack(pady=5)

        theme.label(auto_output_tk, '请输入输出次数:', C).pack(pady=(15, 5))
        auto_output_tk_Entry2 = theme.entry(auto_output_tk, C, width=20)
        auto_output_tk_Entry2.pack(pady=5)
        auto_output_tk_Entry2.insert(0, '1')

        theme.label(auto_output_tk, '请输入开始倒计时(秒):', C).pack(pady=(15, 5))
        auto_output_tk_Entry3 = theme.entry(auto_output_tk, C, width=20)
        auto_output_tk_Entry3.pack(pady=5)
        auto_output_tk_Entry3.insert(0, '3')

        theme.button(auto_output_tk, '开始自动输出', start_auto_output, C,
                     bg='#2196F3', width=15).pack(pady=20)
        theme.label(auto_output_tk, '提示: 点击后切换到目标输入框等待', C,
                    fg='#888', font=('', 8)).pack()

        auto_output_tk.grab_set()
        config.main_tk.wait_window(auto_output_tk)

        # ---- 执行自动化 ----
        if result[0] is None:
            return '已取消'

        text, count, delay = result[0]
        # 倒计时（GUI 会暂时冻结）
        for remaining in range(delay, 0, -1):
            time.sleep(1)
        # 执行循环粘贴
        pyperclip.copy(text)
        for i in range(count):
            time.sleep(random.uniform(0.2, 0.5))
            pyautogui.hotkey('ctrl', 'v')
            pyautogui.press('enter')
        return f'自动输出完成，共输出 {count} 次'
