# ============================================================
# auth.py — 密码安全模块（哈希版）
# 使用 SHA-256 + 随机盐值 对密码进行哈希存储与验证，
# 保证 users_data.json 中不保存明文密码。
# ============================================================
import hashlib
import secrets


def hash_password(password: str, salt: str = None) -> tuple:
    """对密码进行 SHA-256 + 盐值 哈希，返回 (哈希值, 盐值)"""
    if salt is None:
        salt = secrets.token_hex(16)
    h = hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
    return h, salt


def verify_password(password: str, salt: str, stored_hash: str) -> bool:
    """验证密码是否匹配 SHA-256 + 盐值 哈希"""
    computed = hashlib.sha256((salt + password).encode('utf-8')).hexdigest()
    return computed == stored_hash
