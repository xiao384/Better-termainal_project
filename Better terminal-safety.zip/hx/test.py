"""
test.py — 哈希加密演示程序
用于 Better Terminal 项目的密码安全升级测试
"""
import json
import hashlib
import os
import secrets

# ==================== 哈希工具函数 ====================

def hash_password(password: str, salt: str = None) -> tuple[str, str]:
    """使用 SHA-256 + 盐值 对密码进行哈希
    返回: (哈希值, 盐值)
    """
    if salt is None:
        salt = secrets.token_hex(16)  # 生成 32 字符随机盐
    salted = salt + password
    hash_value = hashlib.sha256(salted.encode('utf-8')).hexdigest()
    return hash_value, salt


def verify_password(password: str, salt: str, stored_hash: str) -> bool:
    """验证密码是否匹配"""
    computed_hash, _ = hash_password(password, salt)
    return computed_hash == stored_hash


# ==================== 1. 基础演示 ====================
print("=" * 50)
print("1. 基础哈希演示")
print("=" * 50)

test_password = "1234567890"
hashed, salt = hash_password(test_password)
print(f"原始密码:   {test_password}")
print(f"随机盐值:   {salt}")
print(f"SHA-256:    {hashed}")
print(f"验证正确密码: {verify_password(test_password, salt, hashed)}")
print(f"验证错误密码: {verify_password('wrong', salt, hashed)}")

# ==================== 2. 同密码不同盐值 ====================
print("\n" + "=" * 50)
print("2. 相同密码 + 不同盐值 → 不同哈希（防彩虹表）")
print("=" * 50)

for i in range(3):
    h, s = hash_password("mypassword")
    print(f"  哈希{i+1}: {h[:32]}... (盐: {s[:16]}...)")

# ==================== 3. 多种哈希算法对比 ====================
print("\n" + "=" * 50)
print("3. 多种哈希算法对比")
print("=" * 50)

password = "hello123"
algorithms = {
    "MD5":    lambda p: hashlib.md5(p.encode()).hexdigest(),
    "SHA-1":  lambda p: hashlib.sha1(p.encode()).hexdigest(),
    "SHA-256":lambda p: hashlib.sha256(p.encode()).hexdigest(),
    "SHA-512":lambda p: hashlib.sha512(p.encode()).hexdigest(),
}
for name, func in algorithms.items():
    print(f"  {name:8s}: {func(password)}")

# ==================== 4. 用户数据迁移演示 ====================
print("\n" + "=" * 50)
print("4. 明文密码 → 哈希密码 迁移演示")
print("=" * 50)

# 模拟现有明文数据
old_users = {
    "users_name":     ["root",     "xiaoxiao",      "xiao"],
    "users_password": ["root",     "1234567890",    "xiao"],
    "users_root":     ["root",     "root",          "users"],
}

# 迁移为哈希存储
new_users = {
    "users_name":     old_users["users_name"],
    "users_password_hash": [],
    "users_password_salt": [],
    "users_root":     old_users["users_root"],
}

print("迁移前 (明文):")
for i in range(len(old_users["users_name"])):
    print(f"  {old_users['users_name'][i]:10s} → 密码: {old_users['users_password'][i]}")

for pw in old_users["users_password"]:
    h, s = hash_password(pw)
    new_users["users_password_hash"].append(h)
    new_users["users_password_salt"].append(s)

print("\n迁移后 (哈希):")
for i in range(len(new_users["users_name"])):
    print(f"  {new_users['users_name'][i]:10s} → 哈希: {new_users['users_password_hash'][i][:24]}..."
          f"  盐: {new_users['users_password_salt'][i][:16]}...")

# 验证迁移后的登录
print("\n迁移后登录验证:")
test_cases = [("xiaoxiao", "1234567890"), ("xiao", "wrong_password")]
for name, pw in test_cases:
    for i in range(len(new_users["users_name"])):
        if new_users["users_name"][i] == name:
            ok = verify_password(pw, new_users["users_password_salt"][i],
                                    new_users["users_password_hash"][i])
            print(f"  用户 {name} 密码 '{pw}' → {'✅ 通过' if ok else '❌ 拒绝'}")

# ==================== 5. 迁移后 JSON 结构预览 ====================
print("\n" + "=" * 50)
print("5. 新 users_data.json 结构预览")
print("=" * 50)

# 只显示前16字符，不暴露完整哈希
preview = {
    "users_name": new_users["users_name"],
    "users_password_hash": [h[:16] + "..." for h in new_users["users_password_hash"]],
    "users_password_salt": [s[:16] + "..." for s in new_users["users_password_salt"]],
    "users_root": new_users["users_root"],
}
print(json.dumps(preview, ensure_ascii=False, indent=4))

# ==================== 6. 写入新的用户数据文件 ====================
output_path = os.path.join(os.path.dirname(__file__), 'users_data_hashed.json')
with open(output_path, 'w', encoding='utf-8') as fp:
    json.dump(new_users, fp, ensure_ascii=False, indent=4)
print(f"\n✅ 已生成哈希版用户文件: {output_path}")
print("  可将其重命名为 users_data.json 替换原明文文件")
